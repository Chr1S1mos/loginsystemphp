<?php

function emptyInputSignup($name, $email, $userid, $password, $password_repeat)
{


    if(empty($name) or empty($email) or empty($userid) or
    empty($password) or empty($password_repeat))
    {
        $result = 1;
    }
    else
    {
        $result = 0;
    }
    return $result;
}


function invalidEmail($email)
{
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $result = true;
    }
    else{
        $result= false;
    }
    return $result;
}


function pwdMatch($password, $password_repeat)
{

if ($password !== $password_repeat)
{
    $result = true;
}
else
{
    $result = false;
}
return $result;

}

function createUser($dbconection, $name, $email, $userid, $password)
{
    $hashedPwd = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO members(membersName, membersEmail, membersUid, MembersPwd) VALUES ('$name', '$email', '$userid', '$hashedPwd');";
    $dbconection->query($sql);

}

?>
