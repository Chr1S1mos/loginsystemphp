<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGN UP</title>
    <link rel="stylesheet" href="styles.css" >
</head>
<body class="classbg">
    <h1 class="classh1">Παρακαλώ κάντε εγγραφή</h1>

    <div class=classlink>

    <form action="signup_details.php" method="post">
        <input type="text" name="fname" placeholder="Ονοματεπώνυμο......"  >
        <input type="text" name="email" placeholder="E-mail........." id="lathos">
        <label for="email" id=wrong></label><br>
        <input type="text" name="userid" placeholder="Όνομα χρήστη.......">
        <input type="password" name="password" placeholder="Κωδικός....">
        <input type="password" name="password_repeat" placeholder="Επανάληψη κωδικού....."> <br>
        <input type="submit" name="submit" value="Εγγραφή">
    </form>

    </div>


</body>
</html>

<?php

    if(isset($_GET["error"])){
        if($_GET["error"] == "empty"){
            echo "<p> Fill in all fields !  <h1>^_^<h1> <p>";
        }

    else if ($_GET["error"] == "invalidemail"){

        echo "<p> Invalid Email </p>";
        echo "<style> #lathos {border: 2px solid red;</style>";
        echo '<script> document.getElementById("wrong").innerHTML="Invalid Email" </script>';
    }

}





?>
