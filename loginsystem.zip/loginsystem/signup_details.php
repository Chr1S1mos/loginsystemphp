<?php

if(isset($_POST["submit"]))
{
    $name = $_POST["fname"];
    $email = $_POST["email"];
    $userid = $_POST["userid"];
    $password = $_POST["password"];
    $repeat_password = $_POST["password_repeat"];
}
else
{
    header("location: signup.php");
    exit();
}

require_once "db_details.php";
require_once "functions.php";


if (emptyInputSignup($name, $email, $userid, $password, $repeat_password) == 0)
{
    header("location: signup.php?error=empty");
    exit();
}

if (invalidEmail($email) == true)
{
    header("location: signup.php?error=invalidemail");
    exit();
}

if (pwdMatch($password, $repeat_password) == true)
{
    header("location: signup.php?error=invalidpassword");
    exit();
}

createUser($dbconnection, $name, $email, $userid, $password);

?>
