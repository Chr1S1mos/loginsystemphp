<?php

if(isset($_POST["submit"])){
    $username = $_POST["userid"];
    $password = $_POST["password"];
    
}
else {
    header("location: signup_details.php");
    exit();
}





?>